function [s_base, s_deforme, s_corrige, offset_mesure] = correcteOFFSET(M, Ai, Fi, fe, P0, P1, ax_spectre, ax_correction)
    %  Génération du signal de base
    s_temp = gene_signal(M, Ai, Fi, fe, 0);

    % Signal centré (moyenne nulle : amplitude nulle à 0 Hz)
    s_base = s_temp - mean(s_temp);

    %  Application de la déformation OFFSET (choix 1)
    s_deforme = deform_signal(s_base, 1, P0, P1);

    %  Calcul de la FFT
    N = length(s_deforme);
    S_deforme = abs(fft(s_deforme)) / N;
    S_base    = abs(fft(s_base)) / N;
    
    offset_mesure = S_deforme(1);

    %  Tracer les deux spectres
    if nargin >= 7 && ~isempty(ax_spectre)
        N2 = floor(N/2);
        f = (0:N2-1) * fe / N;
        
        hold(ax_spectre, 'off');
        
        % Signal déformé (en rouge)
        stem(ax_spectre, f, S_deforme(1:N2), 'r', 'LineWidth', 2, 'DisplayName', 'Signal Déformé');
        hold(ax_spectre, 'on');
        
        % Signal de base (en bleu pointillé légèrement décalé pour rester visible)
        stem(ax_spectre, f + 0.1, S_base(1:N2), 'b--', 'LineWidth', 1.2, 'DisplayName', 's_i - \langle s_i \rangle');
        
        grid(ax_spectre, 'on');
        xlabel(ax_spectre, 'Fréquence (Hz)');
        ylabel(ax_spectre, '|S(f)|');
        title(ax_spectre, 'Spectre : de la déformée et de s_i - \langle s_i \rangle');
        legend(ax_spectre, 'show');
    end

    %  Signal corrigé
    s_corrige = s_deforme - offset_mesure;

    if nargin >= 8 && ~isempty(ax_correction)
        T = 1;
        t = (0 : 1/fe : T - 1/fe);
        
        hold(ax_correction, 'off');
        
        % Signal d'origine (en bleu pointillé)
        plot(ax_correction, t, s_temp, 'b--', 'LineWidth', 1.2, 'DisplayName', 'Signal Origine');
        hold(ax_correction, 'on');
        
        % Signal corrigé (en vert)
        plot(ax_correction, t, s_corrige, 'g', 'LineWidth', 1.5, 'DisplayName', 'Signal Corrigé');
        
        grid(ax_correction, 'on');
        xlabel(ax_correction, 'Temps (s)');
        ylabel(ax_correction, 'Amplitude');
        title(ax_correction, 'Correction OFFSET');
        legend(ax_correction, 'show');
    end
end