function f_fond = spectre(ax, s, fe)
    %  Nombre d'échantillons du signal (valeur entiere)
    N = length(s);
    
    %  Calcul de la Transformée de Fourier Rapide (FFT)
    S = abs(fft(s));
    
    %  Découpe de la moitié du spectre (Symétrie de la FFT)
    % IMPORTANT : N/2 peut donner un nombre décimal (float) si N est impair.
    % La fonction floor() force le résultat à devenir un ENTIER STRICT (arrondi inférieur).
    % MATLAB exige un entier car un indice de tableau/case mémoire ne peut pas être un float.
    N2 = floor(N/2);
    
    % Extraction des N2 premiers points (indexation de 1 à l'entier N2)
    S = S(1:N2);
    
    %  Construction de l'axe des fréquences réelles (en Hz)
    f = (0:N2-1) * fe / N;
    
    %  Affichage du graphique dans l'axe de l'IHM
    stem(ax, f, S);
    grid(ax, 'on');
    xlabel(ax, 'Fréquence (Hz)');
    ylabel(ax, '|S(f)|');
    title(ax, 'Spectre du signal');
    
    %  Recherche de la fréquence fondamentale
    if length(S) > 1
        % max() cherche l'amplitude maximale
        % idx renvoie l'INDICE ENTIER de la position du pic dans le tableau
        [~, idx] = max(S(2:end)); % On saute le 1er indice (0 Hz / composante continue)
        
        % Décalage de +1 sur l'indice car on a commencé la recherche à partir de S(2)
        f_fond = f(idx + 1);
    else
        f_fond = 0;
    end
end