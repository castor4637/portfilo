function [s_base, s_deforme, s_corrige, gain_mesure] = correcteGAIN(M, Ai, Fi, fe, P0, P1, ax_spectre, ax_correction)
    %  Génération du signal de base
    s_temp = gene_signal(M, Ai, Fi, fe, 0);

    % Centrage du signal + ajout de +1 pour avoir une composante à 0 Hz
    s_base = (s_temp - mean(s_temp)) + 1;

    %  Application de la déformation GAIN (choix 2 = Gain P1)
    choix_deformation = 2;
    s_deforme = deform_signal(s_base, choix_deformation, P0, P1);

    %  Calcul de la FFT
    N = length(s_deforme);
    S_deforme = abs(fft(s_deforme)) / N;
    S_base    = abs(fft(s_base)) / N;

    %  Estimation du Gain à partir de la composante à 0 Hz (ou sur le pic)
    % À 0 Hz, l'amplitude vaut 1 * P1 = P1
    gain_mesure = S_deforme(1) / S_base(1);

    %  Affichage des spectres sur l'axe de l'IHM (Menu Estimation)
    if nargin >= 7 && ~isempty(ax_spectre)
        N2 = floor(N/2);
        f = (0:N2-1) * fe / N;
        
        hold(ax_spectre, 'off');
        
        % Signal déformé avec le Gain P1 (en rouge)
        stem(ax_spectre, f, S_deforme(1:N2), 'r', 'LineWidth', 2, 'DisplayName', 'Signal Déformé (x P_1)');
        hold(ax_spectre, 'on');
        
        % Signal de base s_i - <s_i> + 1 (en bleu pointillé légèrement décalé)
        stem(ax_spectre, f + 0.1, S_base(1:N2), 'b--', 'LineWidth', 1.2, 'DisplayName', 's_i - \langle s_i \rangle + 1');
        
        grid(ax_spectre, 'on');
        xlabel(ax_spectre, 'Fréquence (Hz)');
        ylabel(ax_spectre, '|S(f)|');
        title(ax_spectre, 'Spectre : Gain sur (s_i - \langle s_i \rangle + 1)');
        legend(ax_spectre, 'show');
    end

    %  Correction du Gain sur le signal déformé
    s_corrige = s_deforme / gain_mesure;

    %  Affichage du signal corrigé sur le deuxième axe de l'IHM
    if nargin >= 8 && ~isempty(ax_correction)
        T = 1;
        t = (0 : 1/fe : T - 1/fe);
        
        hold(ax_correction, 'off');
        
        % Signal d'origine (en bleu pointillé)
        plot(ax_correction, t, s_temp, 'b--', 'LineWidth', 1.2, 'DisplayName', 'Signal Origine');
        hold(ax_correction, 'on');
        
        % Signal corrigé (en vert)
        plot(ax_correction, t, s_corrige, 'g', 'LineWidth', 1.5, 'DisplayName', 'Signal Corrigé');
        
        grid(ax_correction, 'on');
        xlabel(ax_correction, 'Temps (s)');
        ylabel(ax_correction, 'Amplitude');
        title(ax_correction, 'Correction GAIN');
        legend(ax_correction, 'show');
    end
end