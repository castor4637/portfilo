function [s_base, s_deforme, s_corrige, gain_mesure, offset_mesure] = correcteGAIN_OFFSET(M, Ai, Fi, fe, P0, P1, ax_spectre, ax_correction)
    % . Signal de base (avec +1 pour observer le gain à 0 Hz)
    s_temp = gene_signal(M, Ai, Fi, fe, 0);
    s_base = (s_temp - mean(s_temp)) + 1;

    % . Application de la déformation GAIN + OFFSET (choix 3)
    choix_deformation = 3;
    s_deforme = deform_signal(s_base, choix_deformation, P0, P1);

    % . Calcul de la FFT
    N = length(s_deforme);
    S_deforme = abs(fft(s_deforme)) / N;
    S_base    = abs(fft(s_base)) / N;

    % . Estimation du Gain sur un pic alternatif (ex: f > 0 Hz)
    [~, idx_peak] = max(S_base(2:floor(N/2)));
    idx_peak = idx_peak + 1; % Ajustement d'indice
    gain_mesure = S_deforme(idx_peak) / S_base(idx_peak);

    % Estimation de l'Offset à 0 Hz (en retirant la contribution du gain sur le +1)
    offset_mesure = S_deforme(1) - (1 * gain_mesure);

    % . Affichage des spectres
    if nargin >= 7 && ~isempty(ax_spectre)
        N2 = floor(N/2);
        f = (0:N2-1) * fe / N;
        
        hold(ax_spectre, 'off');
        stem(ax_spectre, f, S_deforme(1:N2), 'r', 'LineWidth', 2, 'DisplayName', 'Signal Déformé');
        hold(ax_spectre, 'on');
        stem(ax_spectre, f + 0.1, S_base(1:N2), 'b--', 'LineWidth', 1.2, 'DisplayName', 's_i - \langle s_i \rangle + 1');
        
        grid(ax_spectre, 'on');
        xlabel(ax_spectre, 'Fréquence (Hz)');
        ylabel(ax_spectre, '|S(f)|');
        title(ax_spectre, 'Spectre : Gain + OFFSET');
        legend(ax_spectre, 'show');
    end

    % 6. Correction (Inverse des opérations : Retirer l'offset puis diviser par le gain)
    s_corrige = (s_deforme - offset_mesure) / gain_mesure;

    % 7. Affichage dans l'IHM (Menu Correction)
    if nargin >= 8 && ~isempty(ax_correction)
        T = 1;
        t = (0 : 1/fe : T - 1/fe);
        
        hold(ax_correction, 'off');
        plot(ax_correction, t, s_temp, 'b--', 'LineWidth', 1.2, 'DisplayName', 'Signal Origine');
        hold(ax_correction, 'on');
        plot(ax_correction, t, s_corrige, 'g', 'LineWidth', 1.5, 'DisplayName', 'Signal Corrigé');
        
        grid(ax_correction, 'on');
        xlabel(ax_correction, 'Temps (s)');
        ylabel(ax_correction, 'Amplitude');
        title(ax_correction, 'Correction GAIN + OFFSET');
        legend(ax_correction, 'show');
    end
end