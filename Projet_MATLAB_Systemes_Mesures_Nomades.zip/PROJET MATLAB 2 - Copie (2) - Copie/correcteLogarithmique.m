function [s_base, s_deforme, s_corrige, lambda_estime, mu_estime] = correcteLogarithmique(M, Ai, Fi, fe, lambda, mu, ax_spectre, ax_correction)
    % Génération du signal de base
    s_temp = gene_signal(M, Ai, Fi, fe, 0);
    s_base = s_temp - mean(s_temp); % Signal centré à 0

    % Application de la déformation logarithmique (choix = 6)
    choix_deformation = 6;
    s_deforme = deform_signal(s_base, choix_deformation, lambda, mu);

    %  Estimation de Mu (Offset / composante continue)
    % Quand s_base = 0, log(abs(0)+1) = 0, donc s_deforme vaut mu
    mu_estime = min(s_deforme); 

    %  Régression Linéaire pour estimer Lambda (y = p1 * x)
    % Linéarisation : y = exp(s_deforme - mu) - 1, x = |s_base|
    y = exp(s_deforme - mu_estime) - 1;
    x = abs(s_base(:));
    y = y(:);

    % Ajustement linéaire du premier degré : y = p1*x + p0 avec polyfit
    p = polyfit(x, y, 1);
    lambda_estime = p(1); % Le coefficient directeur donne lambda

    %  Correction (Transformation inverse)
    % Recréation du signal en préservant le signe d'origine
    s_corrige = sign(s_base) .* (exp(s_deforme - mu_estime) - 1) / lambda_estime;

    %  Affichage du Spectre / FFT (si l'axe est fourni)
    if nargin >= 7 && ~isempty(ax_spectre)
        N = length(s_deforme);
        N2 = floor(N/2);
        f = (0:N2-1) * fe / N;
        
        S_deforme = abs(fft(s_deforme)) / N;
        S_base    = abs(fft(s_base)) / N;

        hold(ax_spectre, 'off');
        stem(ax_spectre, f, S_deforme(1:N2), 'r', 'LineWidth', 1.5, 'DisplayName', 'Signal Déformé');
        hold(ax_spectre, 'on');
        stem(ax_spectre, f + 0.1, S_base(1:N2), 'b--', 'LineWidth', 1.2, 'DisplayName', 'Signal Original');
        
        grid(ax_spectre, 'on');
        xlabel(ax_spectre, 'Fréquence (Hz)');
        ylabel(ax_spectre, '|S(f)|');
        title(ax_spectre, 'Spectre : Logarithmique');
        legend(ax_spectre, 'show');
    end

    % Affichage de la Correction (Menu Correction)
    if nargin >= 8 && ~isempty(ax_correction)
        T = 1;
        t = (0 : 1/fe : T - 1/fe);
        
        hold(ax_correction, 'off');
        plot(ax_correction, t, s_base, 'b--', 'LineWidth', 1.2, 'DisplayName', 'Signal Origine');
        hold(ax_correction, 'on');
        plot(ax_correction, t, s_corrige, 'g', 'LineWidth', 1.5, 'DisplayName', 'Signal Corrigé');
        
        grid(ax_correction, 'on');
        xlabel(ax_correction, 'Temps (s)');
        ylabel(ax_correction, 'Amplitude');
        title(ax_correction, 'Correction Logarithmique');
        legend(ax_correction, 'show');
    end
end