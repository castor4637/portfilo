 function sd = deform_signal(s, choix, P0, P1)
    switch choix
        case 1
            % Offset (OFFSET)
            sd = s + P0;
        case 2
            % Gain
            sd = P1 * s;
        case 3
            % Gain + Offset
            sd = P1 * s + P0;
        case 4
            % Offset + Gain
            sd = P1 * (s + P0);
        case 5
            % Exponentielle
            sd = P0 * exp(P1 * s);
        case 6
            % Logarithme
            sd = P1 * log(s) + P0;
        otherwise
            sd = s;
    end
end