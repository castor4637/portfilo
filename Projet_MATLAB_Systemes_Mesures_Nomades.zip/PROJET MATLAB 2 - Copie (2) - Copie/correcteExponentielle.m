function [s_base, s_deforme, s_corrige, lambda_estime, mu_estime] = correcteExponentielle(M, Ai, Fi, fe, lambda, mu, ax_spectre, ax_correction)
    %  Génération du signal de base
    s_temp = gene_signal(M, Ai, Fi, fe, 0);
    s_base = s_temp - mean(s_temp); % Signal centré à 0

    %  Application de la déformation exponentielle (choix = 5)
    choix_deformation = 5;
    s_deforme = deform_signal(s_base, choix_deformation, lambda, mu);

    %  Estimation de Mu (Composante continue/offset minimum)
    mu_estime = min(s_deforme) - exp(lambda * min(s_base));
    
    % En cas de petite dérive, sécurité pour éviter log(0 ou négatif)
    s_sans_mu = s_deforme - min(s_deforme) + 1e-6; 

    %  Régression Linéaire pour estimer Lambda (y = p1 * x)
    % Linéarisation : y = ln(s_deforme - mu), x = s_base
    y = log(s_sans_mu);
    x = s_base(:);
    y = y(:);

    % Ajustement linéaire du premier degré : y = p1*x + p0 avec polyfit
    p = polyfit(x, y, 1);
    lambda_estime = p(1); % Le coefficient directeur donne lambda

    % Correction (Transformation inverse : logarithme puis division par lambda)
    s_corrige = log(s_deforme - mu_estime) / lambda_estime;

    %  Affichage du Spectre / FFT (si l'axe est fourni)
    if nargin >= 7 && ~isempty(ax_spectre)
        N = length(s_deforme);
        N2 = floor(N/2);
        f = (0:N2-1) * fe / N;
        
        S_deforme = abs(fft(s_deforme)) / N;
        S_base    = abs(fft(s_base)) / N;

        hold(ax_spectre, 'off');
        stem(ax_spectre, f, S_deforme(1:N2), 'r', 'LineWidth', 1.5, 'DisplayName', 'Signal Déformé');
        hold(ax_spectre, 'on');
        stem(ax_spectre, f + 0.1, S_base(1:N2), 'b--', 'LineWidth', 1.2, 'DisplayName', 'Signal Original');
        
        grid(ax_spectre, 'on');
        xlabel(ax_spectre, 'Fréquence (Hz)');
        ylabel(ax_spectre, '|S(f)|');
        title(ax_spectre, 'Spectre : Exponentielle');
        legend(ax_spectre, 'show');
    end

    % Affichage de la Correction (Menu Correction)
    if nargin >= 8 && ~isempty(ax_correction)
        T = 1;
        t = (0 : 1/fe : T - 1/fe);
        
        hold(ax_correction, 'off');
        plot(ax_correction, t, s_base, 'b--', 'LineWidth', 1.2, 'DisplayName', 'Signal Origine');
        hold(ax_correction, 'on');
        plot(ax_correction, t, s_corrige, 'g', 'LineWidth', 1.5, 'DisplayName', 'Signal Corrigé');
        
        grid(ax_correction, 'on');
        xlabel(ax_correction, 'Temps (s)');
        ylabel(ax_correction, 'Amplitude');
        title(ax_correction, 'Correction Exponentielle');
        legend(ax_correction, 'show');
    end
end